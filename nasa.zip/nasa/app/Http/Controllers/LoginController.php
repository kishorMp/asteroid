<?php
namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;

class LoginController extends Controller
{
    public function index()
    {              	
		 return view('admin.login');
    }
    public function login(){                 
        return view('admin.login');
    }
    public function authenticate(request $request) {
        $request->validate([
            'email' => 'required|string|email',
            'password' => 'required|string',
        ]);

        $credentials = $request->only('email', 'password');

        if (Auth::attempt($credentials)) {
            return redirect()->intended('admin/dashboard');
        }

        return redirect('login')->with('error', 'Oppes! You have entered invalid credentials'); 
    }
    public function logout(){
        Auth::logout();
        return redirect('login');
    }
}
