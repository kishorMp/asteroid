<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Contact;

class UserController extends Controller
{
    public function index(){        
    	// $contacts = Contact::all();
     //    return view('user.index', compact('contacts'));
        $contacts = Contact::all();
        return view('user.index', compact('contacts'));  
    }

    public function editPost($id, $postid){
    	echo $id.' '.$postid;
    	exit;  
    }

    public function save(Request $request){
        $request->validate([
            'first_name'=> 'required',
            'last_name'=> 'required',
            'email'=> 'required'
        ]);
        $contact = new Contact([
                'first_name'=> $request->get('first_name'),
                'last_name'=> $request->get('last_name'),
                'email'=> $request->get('email'),
                'job_title'=> $request->get('job_title'),
                'city'=> $request->get('city'),
                'country'=> $request->get('country')
        ]);
        $contact->save();
        return redirect('/users')->with('success','Contact With');    	
    }

    public function editUser($id){
        $contact = Contact::find($id);          
        return view('user.edit', compact('contact'));
    }

    public function updateUsers(Request $request) {
         $request->validate([
            'first_name'=> 'required',
            'last_name'=> 'required',
            'email'=> 'required'
        ]);


        $contact = Contact::find($request->get('id'));         
        $contact->first_name = $request->get('first_name');
        $contact->last_name = $request->get('last_name');
        $contact->email = $request->get('email');
        $contact->job_title = $request->get('job_title');
        $contact->city = $request->get('city');
        $contact->country = $request->get('country');        
        $contact->save();
        return redirect('/users')->with('success', 'Update Successfully');
    }

    public function create(){
         return view('user.add');
    }

     public function store(Request $request){        
        var_dump($request);
        exit;
    }
}
