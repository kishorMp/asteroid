<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Validator;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Http\Middleware\AdminMiddleware;
use Ixudra\Curl\Facades\Curl;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
       //    $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request){
            $Asteroiddetails = array(); 
            $line_bar = array();
         if($request->get('startdate')){
            $validator = Validator::make(array(
                'start_date'=>$request->startdate,           
                'end_date'=>$request->enddate,                       
            ),array(
                'start_date' =>'required',            
                'end_date' =>'required',                        
            ));
    
            if($validator->fails()){ 
               return redirect()->back()->withErrors($validator)->withInput();           
            } else { 
                $start_date = $request->get('startdate');
                $start_date = date("Y-m-d", strtotime($start_date));
                $end_date = $request->get('enddate');
                $end_date = date("Y-m-d", strtotime($end_date));
               // $start_date = "2015-09-07";
               // $end_date = "2015-09-08";
                 $url = "https://api.nasa.gov/neo/rest/v1/feed?start_date=$start_date&end_date=$end_date&api_key=mpuHkxKGvSEX6Tg6K737ibRZ83ZL2Xy9z5FyWkde";                
              //  $url = "https://api.nasa.gov/neo/rest/v1/feed?start_date=2015-09-07&end_date=2015-09-08&api_key=mpuHkxKGvSEX6Tg6K737ibRZ83ZL2Xy9z5FyWkde";              
                $response = Curl::to($url)
                            ->get();
                $response = json_decode($response, true);                                  
                $Asteroid_k_p_hr = array();
                $Asteroid_closet_distance = array();
                $Asteroid_avg_min = array();
                $Asteroid_avg_max = array();                
                $startTime = strtotime($start_date.' 12:00');
                $endTime = strtotime($end_date.' 12:00');                                                              
                $k = 0;  
                for ( $i = $startTime; $i <= $endTime; $i = $i + 86400 ) {
                    // $dateCurrent =  $thisDate = date( 'Y-m-d', $i ); 
                    $dateCurrent = date( 'Y-m-d', $i );                    
                    $j = 0;                    
                    if(!empty($response['near_earth_objects'][$dateCurrent])){
                        @$line_bar[$k]['Y'] = date('Y', strtotime($dateCurrent)); 
                        @$line_bar[$k]['M'] = date('m', strtotime($dateCurrent)) - 1; 
                        @$line_bar[$k]['d'] = date('d', strtotime($dateCurrent)); 
                        @$line_bar[$k]['totalAsteroid'] = count($response['near_earth_objects'][$dateCurrent]);
                        foreach($response['near_earth_objects'][$dateCurrent] as $key => $val){ 
                                @$id = $val['id'];
                                @$Asteroid_avg_min[] = $val['estimated_diameter']['kilometers']['estimated_diameter_min'];                                                       
                                @$Asteroid_avg_max[] = $val['estimated_diameter']['kilometers']['estimated_diameter_max'];                           
                                @$Asteroid_closet_distance[$id] = $val['close_approach_data'][$j]['miss_distance']['astronomical'];                                                                                   
                                @$Asteroid_k_p_hr[$id] = $val['close_approach_data'][$j]['relative_velocity']['kilometers_per_hour'];
                            $j++;                            
                        }
                        $Asteroid_avg_min = array_filter($Asteroid_avg_min);                 
                        $Asteroid_avg_max = array_filter($Asteroid_avg_max);                 
                        $Asteroid_closet_distance = array_filter($Asteroid_closet_distance);                 
                        $Asteroid_k_p_hr = array_filter($Asteroid_k_p_hr);
                        
                        $max_speed_id =  array_keys($Asteroid_k_p_hr, max($Asteroid_k_p_hr));
                        $max_speed_id = $max_speed_id[0];  //
                        $max_speed_value = max($Asteroid_k_p_hr); // 
                        

                        $min_distance_id =  array_keys($Asteroid_closet_distance, min($Asteroid_closet_distance));
                        $min_distance_id = $min_distance_id[0];  //
                        $min_distance_value = min($Asteroid_closet_distance); //
                        

                        @$cal_sum_min_avg = array_sum($Asteroid_avg_min);                         
                        @$cal_min_avg = $cal_sum_min_avg/count($Asteroid_avg_min); //
                        @$cal_sum_max_avg = array_sum($Asteroid_avg_max);
                        @$cal_max_avg = $cal_sum_max_avg/count($Asteroid_avg_max); //

                                               
                       $Asteroiddetails =  array($max_speed_id,$max_speed_value,$min_distance_id, $min_distance_value, $cal_min_avg, $cal_max_avg);
                    }
                    $k++;
                }                              
            } 
           // $line_bar = json_encode($line_bar);            
        }        
            
        return view('web.index', ['Asteroiddetails'=>$Asteroiddetails, 'chartData'=>$line_bar]);
    }
    
}
