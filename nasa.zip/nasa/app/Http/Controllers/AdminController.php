<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Contact;
use App\Event;
use App\Sliders;
use Validator;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Http\Middleware\AdminMiddleware;
use ImageResize;

class AdminController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */		
  
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
     
    public function __construct(){
       // $this->middleware('auth');
       // $this->middleware(AdminMiddleware::class);
    }
	public function Dashboard() {
		return view('admin.dashboard');
	} 	
	public function news(){
		 return view('admin.news');		
	}
    public function create()
    {
       return view('admin.dashboard');
    }
    public function profile()
    {        
       return view('admin.profile');
    }

    public function addProfile(Request $request){                    
        $validator = Validator::make(array(
            'first_name'=>$request->txtname,           
            'last_name'=>$request->txtlastname,           
            'email'=>$request->txtemail,                                
        ),array(
            'first_name' =>'required',            
            'last_name' =>'required',            
            'email' =>'required',                                  
        ));

        if($validator->fails()){ 
             return redirect()->back()->withErrors($validator)->withInput();           
        } else {
             $Contacts = new Contact([
            'first_name'=> $request->get('txtname'),
            'last_name'=> $request->get('txtlastname'),
            'email'=> $request->get('txtemail'),
            'password'=> $request->get('txtpassword'),            
            'address'=> $request->get('txtAddress'),
            'pincode'=> $request->get('txtPincode'),
            'job_title'=> $request->get('txt_job_title'),
            'city'=> $request->get('txtcity'),
            'country'=> $request->get('txtcountry')
            ]);
             $Contacts->save();
             $request->session()->flash('message','Contact Add Successfully');
             return redirect()->back();
             // return redirect('/admin/dashboard')->with('success', 'Contact saved!'); 
        }        
    }

    public function addEvents(){        
        $events = Event::all();        
        return view('admin.event',['events'=>$events]);
    }

    public function submitEvents(Request $request){
        if($request->event_photo){ 
            $event_photo = $request->event_photo;
            $event_photo_val = 'mimes:jpeg,JPEG,png,jpg,JPG,gif,svg|max:2048';
        } else {
            $event_photo = '';
            $event_photo_val = '';
        }
        $validator = Validator::make(array(
            'event_name'=>$request->event_name,           
            'event_description'=>$request->event_description,                                                      
            'event_photo'=> $event_photo,
        ),array(
            'event_name' =>'required',     
            'event_description' =>'required',            
             'event_photo' =>$event_photo_val,                        
        ));
        if($validator->fails()){ 
            return redirect()->back()->withErrors($validator)->withInput(); 
        } else {
            if($request->event_photo){
                $imageName = time().'.'.$request->event_photo->extension();
                $request->event_photo->move(public_path('images/event'), $imageName);
            } else {
                $imageName = '';
            }                        
            $events = new Event([
                'event_name'=> $request->get('event_name'),
                'event_description'=> $request->get('event_description'),
                'event_photo' => $imageName,
            ]);
            $events->save();
            $request->session()->flash('message','Event Add Successfully');
            return redirect()->back();           
        }                
    }

    public function deleteEvent(Request $request) { 
        $event_get = Event::where('id',$request->delId)->get('event_photo');
        $image_path = public_path().'/images/event/'.$event_get[0]->event_photo;
        if(file_exists($image_path)){
            unlink($image_path);
        }
        Event::find($request->delId)->delete();
        $request->session()->flash('message','Event Delete Successfully');
        return redirect()->back();                          
    }

    public function editEvents($id){
        $event = Event::find($id);
        return view('admin.editevent', compact('event','id'));
    }
    public function updateEvents(Request $request){
        if($request->event_photo){
            $photo = $request->event_photo;            
            $photo_val = 'mimes:jpeg,JPEG,png,jpg,JPG,gif,svg|max:2048';
        } else {
            $photo = '';            
            $photo_val = '';
        }

        $validator = Validator::make(array(
            'event_id' => $request->event_id,
            'event_name' => $request->event_name,
            'event_description' => $request->event_description,
            'event_photo' => $photo,
        ), array(
            'event_id' => 'required',
            'event_name' => 'required',
            'event_description' => 'required',
            'event_photo' => $photo_val,
        ));

        if($validator->fails()){ 
            return redirect()->back()->withErrors($validator)->withInput(); 
        } else {
            $event_get = Event::where('id',$request->event_id)->get('event_photo');
            if($request->event_photo){
                $image_path = public_path().'/images/event/'.$event_get[0]->event_photo;
                if(file_exists($image_path)){
                    unlink($image_path);
                }                
                $photo = time().'.'.$request->event_photo->extension();
                $request->event_photo->move(public_path('images/event'), $photo);               
            } else {                
                $photo = $event_get[0]->event_photo;                                
            }                         
            $event = Event::find($request->event_id);
            $event->event_name = $request->get('event_name');
            $event->event_description = $request->get('event_description');
            $event->event_photo = $photo;
            $event->save();
            $request->session()->flash('message','Event Update Successfully');
            return redirect('../admin/addEvents'); 
        }

    }

    public function addSlider(){
        return view('admin.slider.addSlider');
    }
    public function submitSlider(Request $request){
        if($request->slider_image){
            $photo_name = $request->slider_image;
            $photo_val = 'mimes:jpeg,JPEG,png,jpg,JPG,gif,svg|max:4048';
        } else {
            $photo_val = '';
            $photo_name = '';
        }
        $validator = Validator::make(array(
            'slider_name'=> $request->slider_name,
            'slider_image'=> $photo_name
        ), array(
            'slider_name'=> 'required',
            'slider_image'=> $photo_val,
        ));
        
        if($validator->fails()){
            return redirect()->back()->withErrors($validator)->withInput();
        } else {
            if($request->slider_image){
                $image = $request->file('slider_image');
                $imagename = time().'.'.$image->extension();
                // $imagename = time().'.'.$request->slider_image->extension();               
        
                $destinationPath = public_path('images/slider/thumb');
                $img = ImageResize::make($image->path());
                $img->resize(100, 100, function ($constraint) {
                    $constraint->aspectRatio();
                })->save($destinationPath.'/'.$imagename);

                $image->move(public_path('images/slider'), $imagename); 
            } else {
                $imagename = '';
                $destinationPath = '';
            }
           
            $slider = new Sliders([
                'slider_name'=> $request->get('slider_name'),
                'slider_image'=> $imagename
            ]);
            $slider->save();            
            $request->session()->flash('message','Slider Add Successfully');            
            return redirect()->back();              
        }       
    }

    public function listSlider(){
        $slider = Sliders::all();
        return view('admin.slider.editSlider', ['slider'=>$slider]);
    }

    public function editSlider($id){
         // $slider = Sliders::find($id);
        $slider = Sliders::where('id', $id)->get('slider_name');
         
         var_dump($slider);
         exit;
        // return view('admin.slider.updateSlider', ['slider'=>$slider]);
    }
    public function deleteSlider(Request $request){

        var_dump($request->get('delId'));
        exit;

    }
   
}
