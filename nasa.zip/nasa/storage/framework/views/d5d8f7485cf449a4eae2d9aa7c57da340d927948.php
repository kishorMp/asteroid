<?php $__env->startSection('homepage'); ?>
<div class="container">
  <h2>Asteroid form</h2>
  <form name="frmnasa" method="post" action="<?php echo e(route('getDetails')); ?>">
    <?php echo csrf_field(); ?>
    <div class="container">
        <div class="col-sm-6">
              <div class="form-group">
            <label for="email">Start Date:</label>
            <input type="date" class="form-control" id="email"  name="startdate">
          </div>
          <div class="form-group">
            <label for="pwd">End Date:</label>
            <input type="date" class="form-control" id="pwd" name="enddate">
          </div>
          
          <button type="submit" class="btn btn-default">Submit</button>
        </div>
    </div>
    
  </form>
</div>

<div class="container">
  <h2>Asteroid form</h2>  
  <table class="table">
    <thead>
      <tr>
        <th>Fastest Asteroid ID</th>
        <th>Fastest Asteroid Speed</th>
        <th>Closest Asteroid Id</th>
        <th>Closest Asteroid Distance</th>
        <th>Min Avg Size</th>
        <th>Max Avg Size</th>
      </tr>
    </thead>
    <tbody>    
    <?php if(count($Asteroiddetails) > 0): ?>
      <tr>
        <td><?php echo e($Asteroiddetails[0]); ?></td>
        <td><?php echo e($Asteroiddetails[1]); ?></td>
        <td><?php echo e($Asteroiddetails[2]); ?></td>
        <td><?php echo e($Asteroiddetails[3]); ?></td>
        <td><?php echo e($Asteroiddetails[4]); ?></td>
        <td><?php echo e($Asteroiddetails[5]); ?></td>
      </tr>
    <?php endif; ?>
    </tbody>
  </table>
</div>

<div id="chartContainer" style="height: 370px; max-width: 920px; margin: 0px auto;"></div>

<?php $__env->stopSection(); ?>

<script>
window.onload = function () {

var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	title:{
		text: "Asteroid Line Chart"
	},
	axisX:{
		valueFormatString: "DD MMM"
	},
	axisY: {
		title: "Number of Asteroid",
		includeZero: false,
		scaleBreaks: {
			autoCalculate: true
		}
	},
	data: [{
		type: "line",
		xValueFormatString: "DD MMM",
		color: "#F08080",
		dataPoints: [
      <?php $__currentLoopData = $chartData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			{ x: new Date(<?php echo e($dat['Y']); ?>, <?php echo e($dat['M']); ?>, <?php echo e($dat['d']); ?>), y: <?php echo e($dat['totalAsteroid']); ?> },
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>						
		]
	}]
});
chart.render();
}
</script>
<?php echo $__env->make('web.home_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Laravel\project\nasa\resources\views/web/index.blade.php ENDPATH**/ ?>