<!DOCTYPE html>
<html lang="en">
<head>
  <title>Asteroid</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
  <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('js/canvasjs.min.js')); ?>"></script>
</head>
<body>

<?php echo $__env->yieldContent('homepage'); ?>
  <!-- Main -->
  </body>
</html><?php /**PATH E:\xampp\htdocs\Laravel\project\nasa\resources\views/web/home_layout.blade.php ENDPATH**/ ?>