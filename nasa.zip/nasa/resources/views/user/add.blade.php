@extends('user_layout')
@section('substance')
<div class="container">
	<div class="row">
			<h1>Add Form<h1>			
	</div>
	<div class="row">
		<form method="post" action="/usersadd">
			@csrf
	          <div class="form-group">    
	              <label>First Name:</label>
	              <input type="text" class="form-control" name="first_name"/>
	          </div>

	          <div class="form-group">
	              <label for="last_name">Last Name:</label>
	              <input type="text" class="form-control" name="last_name"/>
	          </div>

	          <div class="form-group">
	              <label for="email">Email:</label>
	              <input type="text" class="form-control" name="email"/>
	          </div>
	          <div class="form-group">
	              <label for="city">City:</label>
	              <input type="text" class="form-control" name="city"/>
	          </div>
	          <div class="form-group">
	              <label for="country">Country:</label>
	              <input type="text" class="form-control" name="country"/>
	          </div>
	          <div class="form-group">
	              <label for="job_title">Job Title:</label>
	              <input type="text" class="form-control" name="job_title"/>
	          </div>                         
	          <button type="submit" class="btn btn-primary-outline">Add contact</button>
      </form>			
	</div>	
</div>	
@endsection