@extends('web.home_layout')
@section('sreeRamSteel')
<div class="bottombg">
<section>
    <div class="container ">
          <div class="row">
        <div class="col-md-12 product_detai wow fadeInLeft ">
              <h1>Products</h1>
              <div class="bs-example"> 
            <!-- Modal HTML -->
            <div id="myModal" class="modal fade">
                  <div class="modal-dialog">
                <div class="modal-content">
                      <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h4 class="modal-title">Enquiry</h4>
                  </div>
                      <div class="modal-body">
                    <form role="form">
                          <div class="form-group">
                        <label for="recipient-name" class="control-label">Name</label>
                        <input type="text" class="form-control" id="recipient-name">
                      </div>
                          <div class="form-group">
                        <label for="recipient-name" class="control-label">Email Id</label>
                        <input type="text" class="form-control texttrans_none" id="recipient-name">
                      </div>
                          <div class="form-group">
                        <label for="recipient-name" class="control-label">Mobile No</label>
                        <input type="text" class="form-control" id="recipient-name">
                      </div>
                          <div class="form-group">
                        <label for="recipient-name" class="control-label">Product</label>
                        <input type="text" class="form-control" id="recipient-name">
                      </div>
                          <div class="form-group">
                        <label for="message-text" class="control-label">Message</label>
                        <textarea class="form-control" id="message-text"></textarea>
                      </div>
                          <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary">Submit</button>
                      </div>
                        </form>
                  </div>
                    </div>
              </div>
                </div>
          </div>
              <div class="tzportfolio-pages">
            <div class="element">
                  <div class="tz-inner" >
                <div class="tz-image-item"> <img alt="" src="images/angle-iron.jpg"> </div>
                <h6>Erection of Sub Stations</h6>
                <hr />
                <div class="cl"></div>
                <p>We are perceived as one of the leading names in offering Substation Erection Services for the installation of both indoor and also outside sub stations.  </p>
                <div class="click_btn" align="center" ><a href="#" class="btn " data-toggle="modal" data-target="#myModal" data-title="Feedback">Enquiry</a></div>
              </div>
                </div>
            <div class="element">
                  <div class="tz-inner" >
                <div class="tz-image-item"> <img alt="" src="images/minar-steel-tmt.jpg"> </div>
                <h6>Erection of Transmission Lines & Towers</h6>
                <hr />
                <div class="cl"></div>
                <p>We work in giving complete solution for Transmission Line Erection Services. Our services for Transmission Lines incorporate Survey, Foundation, Erection of Towers, Stringing, Testing and Commissioning of lines. </p>
                <div class="click_btn" align="center" ><a href="#" class="btn " data-toggle="modal" data-target="#myModal" data-title="Feedback">Enquiry</a></div>
              </div>
                </div>
            <div class="element">
                  <div class="tz-inner" >
                <div class="tz-image-item"> <img alt="" src="images/page1.jpg"></div>
                <h6>All Types of HT & LT Line Works</h6>
                <hr />
                <div class="cl"></div>
                <p>We are of one of the rumored names occupied with giving world class services of Electrical HT and LT Installation to our customers. We have a group of capable masters prepared under accomplished proficient included in the rendering of the services includes profoundly qualified and able electrical experts and specialists. </p>
                <div class="click_btn" align="center" ><a href="#" class="btn " data-toggle="modal" data-target="#myModal" data-title="Feedback">Enquiry</a></div>
              </div>
                </div>
            <div class="element">
                  <div class="tz-inner" >
                <div class="tz-image-item"> <img alt="" src="images/productbg.jpg"> <!--<a href="#" class="tzfa-search"><i class="fa fa-search-plus"></i></a> --></div>
                <h6>Installation of D. G. Sets & Transformers</h6>
                <hr />
                <div class="cl"></div>
                <p>The service we give is rendered by masters who have enormous encounter in this specific work. One can benefit our services at the business sector standard and aggressive cost.</p>
                <div class="click_btn" align="center" ><a href="#" class="btn " data-toggle="modal" data-target="#myModal" data-title="Feedback">Enquiry</a></div>
              </div>
                </div>
          </div>
            </div>
      </div>
        </div>
  </section>      
<script src="{{ asset('web/js/jquery.isotope.min.js') }} "></script>
<script src="{{ asset('web/js/portfolio.js') }}"></script>
<script>
            var Desktop           =   3,
                tabletportrait    =   3,
                mobilelandscape   =   2,
                mobileportrait    =   1,
                resizeTimer       =   null;
    </script>
@endsection
