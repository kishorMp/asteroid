@extends('web.home_layout')
@section('homepage')
<div class="container">
  <h2>Asteroid form</h2>
  <form name="frmnasa" method="post" action="{{ route('getDetails') }}">
    @csrf
    <div class="container">
        <div class="col-sm-6">
              <div class="form-group">
            <label for="email">Start Date:</label>
            <input type="date" class="form-control" id="email"  name="startdate">
          </div>
          <div class="form-group">
            <label for="pwd">End Date:</label>
            <input type="date" class="form-control" id="pwd" name="enddate">
          </div>
          
          <button type="submit" class="btn btn-default">Submit</button>
        </div>
    </div>
    
  </form>
</div>

<div class="container">
  <h2>Asteroid form</h2>  
  <table class="table">
    <thead>
      <tr>
        <th>Fastest Asteroid ID</th>
        <th>Fastest Asteroid Speed</th>
        <th>Closest Asteroid Id</th>
        <th>Closest Asteroid Distance</th>
        <th>Min Avg Size</th>
        <th>Max Avg Size</th>
      </tr>
    </thead>
    <tbody>    
    @if(count($Asteroiddetails) > 0)
      <tr>
        <td>{{ $Asteroiddetails[0] }}</td>
        <td>{{ $Asteroiddetails[1] }}</td>
        <td>{{ $Asteroiddetails[2] }}</td>
        <td>{{ $Asteroiddetails[3] }}</td>
        <td>{{ $Asteroiddetails[4] }}</td>
        <td>{{ $Asteroiddetails[5] }}</td>
      </tr>
    @endif
    </tbody>
  </table>
</div>

<div id="chartContainer" style="height: 370px; max-width: 920px; margin: 0px auto;"></div>

@endsection

<script>
window.onload = function () {

var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	title:{
		text: "Asteroid Line Chart"
	},
	axisX:{
		valueFormatString: "DD MMM"
	},
	axisY: {
		title: "Number of Asteroid",
		includeZero: false,
		scaleBreaks: {
			autoCalculate: true
		}
	},
	data: [{
		type: "line",
		xValueFormatString: "DD MMM",
		color: "#F08080",
		dataPoints: [
      @foreach($chartData as $dat)
			{ x: new Date({{$dat['Y']}}, {{$dat['M']}}, {{$dat['d']}}), y: {{$dat['totalAsteroid']}} },
      @endforeach						
		]
	}]
});
chart.render();
}
</script>