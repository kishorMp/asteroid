@extends('web.home_layout')
@section('sreeRamSteel')
<div class="bottombg">
<section style="background-color:#fff;">
    <div class="container ">
      <div class="row">
        <div class="col-md-12 product_detai wow fadeInLeft ">
          <h1>Contact Us</h1>
          <div class="row out_infospac">
            <div class="col-md-12 left_big">
              <div class="row">
                <div class="col-xs-12 col-sm-4 col-md-4 info_box wow fadeInLeft"> <i class="fa fa-map-marker"></i> <span> Shreeram Steels 33 , Imambada Square, Great Nag Road , Near Post Office, Nagpur- 440 003 (Maharashtra). </span> </div>
                <div class="col-xs-12 col-sm-4 col-md-4 info_box wow fadeInDown"> <i class="fa fa-mobile"></i> <span> +91 9890258545 <br />
                  +91 (712) 2740313, 
                  +91 (712) 2701569 </span> </div>
                <div class="col-xs-12 col-sm-4 col-md-4 info_box wow fadeInRight"> <i class="fa fa-envelope"></i> <span> <a href="mailto:info@shreeramsteels.com?Subject=Enquiry" target="_top"> info@shreeramsteels.com </a> </span> </div>
              </div>
              
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <div class="container ">
    <div class="row">
    <div class="col-md-6 out_infospac">
                  <h3>Business Enquiry Form</h3>
                  <form role="form">
                    <div class="cl"></div>
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <input type="text" class="form-control texttrans_none" placeholder="Name" id="recipient-name">
                        </div>
                        <div class="form-group">
                          <input type="text" class="form-control texttrans_none" placeholder="Location" id="recipient-name">
                        </div>
                        <div class="form-group">
                          <input type="text" class="form-control" placeholder="District" id="recipient-name">
                        </div>
                        <div class="form-group">
                          <input type="text" class="form-control texttrans_none" placeholder="State" id="recipient-name">
                        </div>
                        <div class="form-group">
                          <input type="email" class="form-control" placeholder="Email Id" id="recipient-name">
                        </div>
                        <div class="form-group">
                          <input type="text" class="form-control" placeholder="Mobile No" id="recipient-name">
                        </div>
                        <div class="form-group">
                          <textarea rows="3" class="form-control text_area" id="message-text" placeholder=" Describe your Requirements in Detail"></textarea>
                        </div>
                        <div class="form-group " align="right" >
                          <button type="button" class="btn btn-danger">Send Enquiry</button>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
      <div class="col-md-6 mapbg wow fadeInUp ">
        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d476362.49416170985!2d79.34957161240233!3d21.12922528682504!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sin!4v1439289542959" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen></iframe>
      </div>
    </div>
    </div>
  </section>
  <section>
   
  </section>
  
<script  type="text/javascript">
jQuery(function($) {'use strict',

	//#main-slider
	$(function(){
		$('#main-slider.carousel').carousel({
			interval: 8000
		});
	});


	// accordian
	$('.accordion-toggle').on('click', function(){
		$(this).closest('.panel-group').children().each(function(){
		$(this).find('>.panel-heading').removeClass('active');
		 });

	 	$(this).closest('.panel-heading').toggleClass('active');
	});

	//Initiat WOW JS
	new WOW().init();

	// portfolio filter
	$(window).load(function(){'use strict';
		var $portfolio_selectors = $('.portfolio-filter >li>a');
		var $portfolio = $('.portfolio-items');
		$portfolio.isotope({
			itemSelector : '.portfolio-item',
			layoutMode : 'fitRows'
		});
		
		$portfolio_selectors.on('click', function(){
			$portfolio_selectors.removeClass('active');
			$(this).addClass('active');
			var selector = $(this).attr('data-filter');
			$portfolio.isotope({ filter: selector });
			return false;
		});
	});

	// Contact form
	var form = $('#main-contact-form');
	form.submit(function(event){
		event.preventDefault();
		var form_status = $('<div class="form_status"></div>');
		$.ajax({
			url: $(this).attr('action'),

			beforeSend: function(){
				form.prepend( form_status.html('<p><i class="fa fa-spinner fa-spin"></i> Email is sending...</p>').fadeIn() );
			}
		}).done(function(data){
			form_status.html('<p class="text-success">' + data.message + '</p>').delay(3000).fadeOut();
		});
	});

	
	//goto top
	$('.gototop').click(function(event) {
		event.preventDefault();
		$('html, body').animate({
			scrollTop: $("body").offset().top
		}, 500);
	});	

	//Pretty Photo
	$("a[rel^='prettyPhoto']").prettyPhoto({
		social_tools: false
	});	
});
</script> 
@endsection
