@extends('web.home_layout')
@section('sreeRamSteel')
<div class="bottombg">
<section id="bgwite">
    <div class="container articalbg">
              <div class="row ">
        <div class="col-md-12">
                  <h1>Video Gallery</h1>
                </div>
      </div>
              <div class="row video_bg">
        <div class="col-xs-12 col-sm-4 col-md-4 ">
                  <div class="vidbo"> <a href="http://www.youtube.com/watch?v=ZJX-ndOM4VM" data-toggle="lightbox" data-gallery="youtubevideos" > <img src="images/Untitled.png" class="img-responsive"> </a>
            <div class="cl"></div>
          </div>
                </div>
        <div class="col-xs-12 col-sm-4 col-md-4 ">
                  <div class="vidbo"> <a href="http://youtu.be/iQ4D273C7Ac" data-toggle="lightbox" data-gallery="youtubevideos" > <img src="//i1.ytimg.com/vi/iQ4D273C7Ac/mqdefault.jpg" class="img-responsive"> </a>
            <div class="cl"></div>
          </div>
                </div>
        <div class="col-xs-12 col-sm-4 col-md-4 ">
                  <div class="vidbo"> <a href="//www.youtube.com/embed/b0jqPvpn3sY" data-toggle="lightbox" data-gallery="youtubevideos" > <img src="//i1.ytimg.com/vi/b0jqPvpn3sY/mqdefault.jpg" class="img-responsive"> </a>
            <div class="cl"></div>
          </div>
                </div>
                
                <div class="col-xs-12 col-sm-4 col-md-4 ">
                  <div class="vidbo"> <a href="http://www.youtube.com/watch?v=ZJX-ndOM4VM" data-toggle="lightbox" data-gallery="youtubevideos" > <img src="images/Untitled.png" class="img-responsive"> </a>
            <div class="cl"></div>
          </div>
                </div>
                
                <div class="col-xs-12 col-sm-4 col-md-4 ">
                  <div class="vidbo"> <a href="http://www.youtube.com/watch?v=ZJX-ndOM4VM" data-toggle="lightbox" data-gallery="youtubevideos" > <img src="images/Untitled.png" class="img-responsive"> </a>
            <div class="cl"></div>
          </div>
                </div>
                
                <div class="col-xs-12 col-sm-4 col-md-4 ">
                  <div class="vidbo"> <a href="http://www.youtube.com/watch?v=ZJX-ndOM4VM" data-toggle="lightbox" data-gallery="youtubevideos" > <img src="images/Untitled.png" class="img-responsive"> </a>
            <div class="cl"></div>
          </div>
                </div>
      </div>
            </div>
  </section>
          <div class="cl"></div>
          
<!--video script-->
<script src="js/ekko-lightbox.min.js"></script>
<script type="text/javascript">
			$(document).ready(function ($) {

				// delegate calls to data-toggle="lightbox"
				$(document).delegate('*[data-toggle="lightbox"]:not([data-gallery="navigateTo"])', 'click', function(event) {
					event.preventDefault();
					return $(this).ekkoLightbox({
						onShown: function() {
							if (window.console) {
								return console.log('Checking our the events huh?');
							}
						},
						onNavigate: function(direction, itemIndex) {
							if (window.console) {
								return console.log('Navigating '+direction+'. Current item: '+itemIndex);
							}
						}
					});
				});

				//Programatically call
				$('#open-image').click(function (e) {
					e.preventDefault();
					$(this).ekkoLightbox();
				});
				$('#open-youtube').click(function (e) {
					e.preventDefault();
					$(this).ekkoLightbox();
				});

				$(document).delegate('*[data-gallery="navigateTo"]', 'click', function(event) {
					event.preventDefault();
					return $(this).ekkoLightbox({
						onShown: function() {
							var a = this.modal_content.find('.modal-footer a');
							if(a.length > 0) {
								a.click(function(e) {
									e.preventDefault();
									this.navigateTo(2);
								}.bind(this));
							}
						}
					});
				});

			});
		</script>
@endsection
