@extends('web.home_layout')
@section('sreeRamSteel')
<div class="bottombg">
<section id="bgwite">
    <div class="container articalbg">
    <div class="row ">
        <div class="col-md-12">
         <h1>Details</h1>
          
        </div>
        </div>
      <div class="row ">
          <div class="col-sm-4 col-md-4 lef_oferdeta wow fadeInRight">
          <img src="{{asset('web/images/angle-iron.jpg') }}" />
        </div>
        <div class="col-sm-8 col-md-8 rig_ofdet wow fadeInRight">
        <h2>Myraa Red Georgette Deisgner </h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed</p>
        <a href="#" class="enqbtn" >Enquiry</a>
        </div>
      </div>
      
      
      
      <div class="row">
        <div class="col-sm-3 col-md-3 offerbox wow fadeInRight">
        <div class="ofinnbox">
        <a href="{{ route('offerDetails') }}">
         <h2>Offer Heading</h2>
         <img src="{{asset('web/images/4.jpg') }}" />
         <p>A strong focus on Value Creation has helped the Group build an enviable reputation founded in honest and transparent approaches.</p>
         </a>
         </div>
        </div>
        
        <div class="col-sm-3 col-md-3 offerbox wow fadeInDown">
        <div class="ofinnbox">
        <a href="{{ route('offerDetails') }}">
         <h2>Offer Heading</h2>
         <img src="{{asset('web/images/angle-iron.jpg') }}" />
         <p>A strong focus on Value Creation has helped the Group build an enviable reputation founded in honest and transparent approaches.</p>
         </a>
         </div>
        </div>
        
        <div class="col-sm-3 col-md-3 offerbox wow fadeInLeft">
        <div class="ofinnbox">
        <a href="{{ route('offerDetails') }}">
         <h2>Offer Heading</h2>
         <img src="{{asset('web/images/minar-steel-tmt.jpg') }}" />
         <p>A strong focus on Value Creation has helped the Group build an enviable reputation founded in honest and transparent approaches.</p>
         </a>
         </div>
        </div>
        
        <div class="col-sm-3 col-md-3 offerbox wow fadeInUp">
        <div class="ofinnbox">
        <a href="{{ route('offerDetails') }}">
         <h2>Offer Heading</h2>
         <img src="{{asset('web/images/page1.jpg') }}" />
         <p>A strong focus on Value Creation has helped the Group build an enviable reputation founded in honest and transparent approaches.</p>
         </a>
         </div>
        </div>
        
        
      </div>
    </div>
  </section>
  <div class="cl"></div>
  
  <script  type="text/javascript">
jQuery(function($) {'use strict',

	//#main-slider
	$(function(){
		$('#main-slider.carousel').carousel({
			interval: 8000
		});
	});


	// accordian
	$('.accordion-toggle').on('click', function(){
		$(this).closest('.panel-group').children().each(function(){
		$(this).find('>.panel-heading').removeClass('active');
		 });

	 	$(this).closest('.panel-heading').toggleClass('active');
	});

	//Initiat WOW JS
	new WOW().init();

	// portfolio filter
	$(window).load(function(){'use strict';
		var $portfolio_selectors = $('.portfolio-filter >li>a');
		var $portfolio = $('.portfolio-items');
		$portfolio.isotope({
			itemSelector : '.portfolio-item',
			layoutMode : 'fitRows'
		});
		
		$portfolio_selectors.on('click', function(){
			$portfolio_selectors.removeClass('active');
			$(this).addClass('active');
			var selector = $(this).attr('data-filter');
			$portfolio.isotope({ filter: selector });
			return false;
		});
	});

	// Contact form
	var form = $('#main-contact-form');
	form.submit(function(event){
		event.preventDefault();
		var form_status = $('<div class="form_status"></div>');
		$.ajax({
			url: $(this).attr('action'),

			beforeSend: function(){
				form.prepend( form_status.html('<p><i class="fa fa-spinner fa-spin"></i> Email is sending...</p>').fadeIn() );
			}
		}).done(function(data){
			form_status.html('<p class="text-success">' + data.message + '</p>').delay(3000).fadeOut();
		});
	});

	
	//goto top
	$('.gototop').click(function(event) {
		event.preventDefault();
		$('html, body').animate({
			scrollTop: $("body").offset().top
		}, 500);
	});	

	//Pretty Photo
	$("a[rel^='prettyPhoto']").prettyPhoto({
		social_tools: false
	});	
});
</script>
@endsection
