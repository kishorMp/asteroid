@extends('web.home_layout')
@section('sreeRamSteel')
<div class="bottombg">
<section>
      <div class="container">
        <div class="row">
          <div class="col-md-12 innerpage_slid">
            <img src="images/banner_larg.jpg" alt="First slide">
            <div class="heading_titl">Broucher Download</div>
          </div>
        </div>
      </div>
    </section>
  <section id="bgwite">
    <div class="container articalbg">
      <div class="row ">
        <div class="col-md-12 brouchlist">
          <h1>Broucher Download</h1>
          
          <ul>
             <li><a href="#"> <i class="fa fa-arrow-circle-o-left"></i>Steel Annual Report (2013 - 2014)</a></li>
             <li><a href="#"> <i class="fa fa-arrow-circle-o-left"></i>Steel Annual Report (2013 - 2014)</a></li>
             <li><a href="#"> <i class="fa fa-arrow-circle-o-left"></i>Steel Annual Report (2013 - 2014)</a></li>
             <li><a href="#"> <i class="fa fa-arrow-circle-o-left"></i>Steel Annual Report (2013 - 2014)</a></li>
             <li><a href="#"> <i class="fa fa-arrow-circle-o-left"></i>Steel Annual Report (2013 - 2014)</a></li>
             <li><a href="#"> <i class="fa fa-arrow-circle-o-left"></i>Steel Annual Report (2013 - 2014)</a></li>
             <li><a href="#"> <i class="fa fa-arrow-circle-o-left"></i>Steel Annual Report (2013 - 2014)</a></li>
             <li><a href="#"> <i class="fa fa-arrow-circle-o-left"></i>Steel Annual Report (2013 - 2014)</a></li>
             <li><a href="#"> <i class="fa fa-arrow-circle-o-left"></i>Steel Annual Report (2013 - 2014)</a></li>
          </ul>
        </div>
      </div>
      
    </div>
  </section>
  <div class="cl"></div>
  
  <section id="fixbg">
    <div class="container ">
      <div class="row">
        <div class="col-md-12 wow fadeInLeft ">
          <h1>Direct Steel Sales. </h1>
          <h3>All Week! </h3>
          <br />
          <div class="requestbtn"><a href="#" class="btn btn-primary btn-lg">Request for Offer</a></div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12 wow fadeInRight "> </div>
      </div>
    </div>
    <div class="tranbgcolor">
      <div class="container ">
        <div class="row">
          <div class="col-md-12">
            <ul id="flexiselDemo3">
              <li><a href="#"><img src="images/clientlogo1.jpg" alt="" title="" /></a></li>
              <li><a href="#"><img src="images/clientlogo2.jpg" /></a></li>
              <li><a href="#"><img src="images/clientlogo3.jpg" /></a></li>
              <li><a href="#"><img src="images/clientlogo4.jpg" /></a></li>
              <li><a href="#"><img src="images/clientlogo5.jpg" /></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>  
  <script  type="text/javascript">
jQuery(function($) {'use strict',

	//#main-slider
	$(function(){
		$('#main-slider.carousel').carousel({
			interval: 8000
		});
	});


	// accordian
	$('.accordion-toggle').on('click', function(){
		$(this).closest('.panel-group').children().each(function(){
		$(this).find('>.panel-heading').removeClass('active');
		 });

	 	$(this).closest('.panel-heading').toggleClass('active');
	});

	//Initiat WOW JS
	new WOW().init();

	// portfolio filter
	$(window).load(function(){'use strict';
		var $portfolio_selectors = $('.portfolio-filter >li>a');
		var $portfolio = $('.portfolio-items');
		$portfolio.isotope({
			itemSelector : '.portfolio-item',
			layoutMode : 'fitRows'
		});
		
		$portfolio_selectors.on('click', function(){
			$portfolio_selectors.removeClass('active');
			$(this).addClass('active');
			var selector = $(this).attr('data-filter');
			$portfolio.isotope({ filter: selector });
			return false;
		});
	});

	// Contact form
	var form = $('#main-contact-form');
	form.submit(function(event){
		event.preventDefault();
		var form_status = $('<div class="form_status"></div>');
		$.ajax({
			url: $(this).attr('action'),

			beforeSend: function(){
				form.prepend( form_status.html('<p><i class="fa fa-spinner fa-spin"></i> Email is sending...</p>').fadeIn() );
			}
		}).done(function(data){
			form_status.html('<p class="text-success">' + data.message + '</p>').delay(3000).fadeOut();
		});
	});

	
	//goto top
	$('.gototop').click(function(event) {
		event.preventDefault();
		$('html, body').animate({
			scrollTop: $("body").offset().top
		}, 500);
	});	

	//Pretty Photo
	$("a[rel^='prettyPhoto']").prettyPhoto({
		social_tools: false
	});	
});
</script>
@endsection
