@extends('web.home_layout')
@section('sreeRamSteel')
<div class="bottombg">
<section>
    <div class="container">
      <div class="row">
        <div class="col-md-12 innerpage_slid"> <img src="images/banner_larg.jpg" alt="First slide">
          <div class="heading_titl">Buying Steel</div>
        </div>
      </div>
    </div>
  </section>
  <section>
    <div class="container articalbg">
      <div class="row ">
        <div class="col-md-12">
          <h1>Buying Steel</h1>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12 bg_tab ">
          <div class="bs-example" data-example-id="collapse-accordion">
            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
              <div class="panel panel-default">
                <div class="panel-heading" role="tab" id="headingOne" >
                  <h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne" class=" bybtn"> Buy Steel</a> </h4>
                </div>
                <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                  <div class="panel-body">
                    <div class="table-responsive">
                      <table class="table">
                        <thead>
                          <tr class="info">
                            <th>BrandName</th>
                            <th>Size</th>
                            <th>Rate</th>
                            <th>Quantity In Ton</th>
                            <th>Total</th>
                            <th>Add Brand</th>
                          </tr>
                        </thead>
                        <tbody>
                        <form class="form-horizontal registerForm">
                          <tr>
                            <td><div class="form-group">
                                <div class="col-sm-12 col-md-12">
                                  <select class="form-control " >
                                    <option selected="selected" value="---select---">---select---</option>
                                    <option value="TATA Tiscon">TATA Tiscon</option>
                                    <option value="Kamdhenu">Kamdhenu</option>
                                    <option value="Raipur ISI">Raipur ISI</option>
                                  </select>
                                </div>
                              </div></td>
                            <td><div class="form-group">
                                <div class="col-sm-12 col-md-12">
                                  <select class="form-control " >
                                    <option selected="selected" value="---select---">---select---</option>
                                    <option value="TATA Tiscon">TATA Tiscon</option>
                                    <option value="Kamdhenu">Kamdhenu</option>
                                    <option value="Raipur ISI">Raipur ISI</option>
                                  </select>
                                </div>
                              </div></td>
                            <td></td>
                            <td><div class="form-group">
                                <div class="col-sm-12 col-md-12">
                                  <input type="text" class="form-control  " name=""  placeholder=""/>
                                </div>
                              </div></td>
                            <td><div class="col-sm-12 col-md-12">
                                <input type="text" class="form-control  " name=""  placeholder=""/>
                              </div></td>
                            <td><div class="form-group">
                                <div class="col-sm-12 col-md-12" align="center">
                                  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal" data-title="Feedback">Add</button>
                                </div>
                              </div></td>
                          </tr>
                          <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td><div class="form-group">
                                <div class="col-sm-12 col-md-12"><a href="#" class="btn btn-danger" data-toggle="modal" data-target="#myModal" data-title="Feedback">Get Invoice</a> </div>
                              </div></td>
                            <td></td>
                            <td></td>
                          </tr>
                        </form>
                          </tbody>
                      </table>
                      <div class="bs-example">
                        <div id="myModal" class="modal fade">
                          <div class="modal-dialog">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                <h4 class="modal-title">Login Your Account</h4>
                              </div>
                              <div class="modal-body">
                                  <form role="form">
                                    <div class="form-group">
                                      <label for="recipient-name" class="control-label">Email Id</label>
                                      <input type="text" class="form-control texttrans_none" id="recipient-name">
                                    </div>
                                    <div class="form-group">
                                      <label for="recipient-name" class="control-label">Password</label>
                                      <input type="text" class="form-control" id="recipient-name">
                                    </div>
                                    
                                    
                                    <div class="modal-footer">
                                    <div align="left"> <a href="#">Forgot Password</a></div>
                                      
                                      <div align="right"> <button type="button" class="btn btn-primary">Submit</button></div>
                                    </div>
                                    
                                    <div class="form-group">
                                   
                                    <div class="forgotbtn">  <a href="registration_form.php" class="">I have no Account</a></div>
                                    </div>
                                  </form>
                                </div>
                              
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      
                      
                      
                    </div>
                  </div>
                </div>
              </div>
              <div class="panel panel-default">
                <div class="panel-heading" role="tab" id="headingTwo" >
                  <h4 class="panel-title"> <a class="collapsed bybtn" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo" > Weight Chart </a> </h4>
                </div>
                <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                  <div class="panel-body">
                    <div class="table-responsive">
                      <table class="table">
                        <thead>
                          <tr class="info">
                            <th valign="top">Size</th>
                            <th valign="top">Section mtr</th>
                            <th  valign="top" title="Weight of Standard bar ( 12 meter length)">WT/Rod<br />
                              (12 mtr)</th>
                            <th valign="top">Tata Brand (weight/ bundle)</th>
                            <th valign="top">Kamdhenu Brand (weight/ bundle)</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td>32mm</td>
                            <td>6.30 kg/meter</td>
                            <td>75.6 kg</td>
                            <td>1 Rod</td>
                            <td></td>
                          </tr>
                          <tr>
                            <td>25mm</td>
                            <td>3.846 kg/meter</td>
                            <td>46.15 kg</td>
                            <td>2 Rod</td>
                            <td></td>
                          </tr>
                          <tr>
                            <td>20mm</td>
                            <td>2.46 kg/meter</td>
                            <td>29.6 kg</td>
                            <td></td>
                            <td></td>
                          </tr>
                          <tr>
                            <td>16mm</td>
                            <td>1.575 kg/meter</td>
                            <td>18.9kg</td>
                            <td></td>
                            <td></td>
                          </tr>
                          <tr>
                            <td>12mm</td>
                            <td>0.888 kg/meter</td>
                            <td>10.6kg</td>
                            <td></td>
                            <td></td>
                          </tr>
                          <tr>
                            <td>10mm</td>
                            <td>0.617 kg/meter</td>
                            <td>7.4kg</td>
                            <td></td>
                            <td></td>
                          </tr>
                          <tr>
                            <td>8mm</td>
                            <td>0.390 kg/meter</td>
                            <td>4.8 kg</td>
                            <td></td>
                            <td></td>
                          </tr>
                          <tr>
                            <td>6mm</td>
                            <td>0.222 kg/meter</td>
                            <td>2.6 kg</td>
                            <td></td>
                            <td></td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
              <div class="panel panel-default">
                <div class="panel-heading" role="tab" id="headingThree" >
                  <h4 class="panel-title"> <a href="faq.php" class="bybtn" >FAQ</a> </h4>
                </div>
                <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                  <div class="panel-body"> </div>
                </div>
              </div>
            </div>
          </div>
          <!-- /example --> 
        </div>
        <div class="cl"></div>
      </div>
    </div>
  </section>
  <div class="cl"></div>
  
<script  type="text/javascript">
jQuery(function($) {'use strict',

	//#main-slider
	$(function(){
		$('#main-slider.carousel').carousel({
			interval: 8000
		});
	});


	// accordian
	$('.accordion-toggle').on('click', function(){
		$(this).closest('.panel-group').children().each(function(){
		$(this).find('>.panel-heading').removeClass('active');
		 });

	 	$(this).closest('.panel-heading').toggleClass('active');
	});

	//Initiat WOW JS
	new WOW().init();

	// portfolio filter
	$(window).load(function(){'use strict';
		var $portfolio_selectors = $('.portfolio-filter >li>a');
		var $portfolio = $('.portfolio-items');
		$portfolio.isotope({
			itemSelector : '.portfolio-item',
			layoutMode : 'fitRows'
		});
		
		$portfolio_selectors.on('click', function(){
			$portfolio_selectors.removeClass('active');
			$(this).addClass('active');
			var selector = $(this).attr('data-filter');
			$portfolio.isotope({ filter: selector });
			return false;
		});
	});

	// Contact form
	var form = $('#main-contact-form');
	form.submit(function(event){
		event.preventDefault();
		var form_status = $('<div class="form_status"></div>');
		$.ajax({
			url: $(this).attr('action'),

			beforeSend: function(){
				form.prepend( form_status.html('<p><i class="fa fa-spinner fa-spin"></i> Email is sending...</p>').fadeIn() );
			}
		}).done(function(data){
			form_status.html('<p class="text-success">' + data.message + '</p>').delay(3000).fadeOut();
		});
	});

	
	//goto top
	$('.gototop').click(function(event) {
		event.preventDefault();
		$('html, body').animate({
			scrollTop: $("body").offset().top
		}, 500);
	});	

	//Pretty Photo
	$("a[rel^='prettyPhoto']").prettyPhoto({
		social_tools: false
	});	
});
</script> 
@endsection
