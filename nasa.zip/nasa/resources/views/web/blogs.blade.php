@extends('web.home_layout')
@section('sreeRamSteel')
<div class="bottombg">
<div id="blog">
    <div class="container">
        <div class="row ">
        <div class="col-md-12">
          <h1>Blogs</h1></div> 
        <div class="cl"></div> 
        </div>
      </div>
    <div class="container">
      <div class="row">
        <div class="col-sm-12  blogsdetai_page">
         <h2>Latest Form The Blogs</h2>
          <div class="row blo_spacdiv">
            <div class="col-md-2">
            <div class=" col-sm-6 col-md-12 date_btnl"><i class="fa fa-calendar"></i> 8/7/2015</div>
             <div class="col-sm-6 col-md-12 byadminbtn"> By Admin</div>
            </div>
            <div class="col-sm-12 col-md-10 detailblog"> <a href="blogs_details.php"><img src="images/banner1.jpg"/>
              <h3>Aliquam Erat Volutpat</h3>
              </a>
             
              <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta. Fusce suscipit varius mi. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nulla dui. Fusce feugiat malesuada odio. Morbi nunc odio, gravida at, cursus nec, luctus a, lorem. Maecenas tristique orci ac sem. Duis ultricies pharetra magna. Donec accumsan malesuada orci. Donec sit amet eros. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Mauris fermentum dictum magna. Sed laoreet aliquam leo.</p>
              <div class="view_more" align="left"><a href="blogs_details.php">View More</a></div>
              
            </div>
          </div>
          
          
          <div class="row blo_spacdiv">
            <div class="col-md-2">
            <div class=" col-sm-6 col-md-12 date_btnl"><i class="fa fa-calendar"></i> 8/7/2015</div>
             <div class="col-sm-6 col-md-12 byadminbtn"> By Admin</div>
            </div>
            <div class="col-sm-12 col-md-10 detailblog"> <a href="blogs_details.php"><img src="images/banner1.jpg"/>
              <h3>Aliquam Erat Volutpat</h3>
              </a>
             
              <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta. Fusce suscipit varius mi. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nulla dui. Fusce feugiat malesuada odio. Morbi nunc odio, gravida at, cursus nec, luctus a, lorem. Maecenas tristique orci ac sem. Duis ultricies pharetra magna. Donec accumsan malesuada orci. Donec sit amet eros. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Mauris fermentum dictum magna. Sed laoreet aliquam leo.</p>
              <div class="view_more" align="left"><a href="blogs_details.php">View More</a></div>
              
            </div>
          </div>
          
          
          
          <div class="row blo_spacdiv">
            <div class="col-md-2">
            <div class=" col-sm-6 col-md-12 date_btnl"><i class="fa fa-calendar"></i> 8/7/2015</div>
             <div class="col-sm-6 col-md-12 byadminbtn"> By Admin</div>
            </div>
            <div class="col-sm-12 col-md-10 detailblog"> <a href="blogs_details.php"><img src="images/banner1.jpg"/>
              <h3>Aliquam Erat Volutpat</h3>
              </a>
             
              <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta. Fusce suscipit varius mi. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nulla dui. Fusce feugiat malesuada odio. Morbi nunc odio, gravida at, cursus nec, luctus a, lorem. Maecenas tristique orci ac sem. Duis ultricies pharetra magna. Donec accumsan malesuada orci. Donec sit amet eros. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Mauris fermentum dictum magna. Sed laoreet aliquam leo.</p>
              <div class="view_more" align="left"><a href="blogs.php">View More</a></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
@endsection
