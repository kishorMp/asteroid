@extends('web.home_layout')
@section('sreeRamSteel')
<div class="bottombg">
<section>
      <div class="container">
        <div class="row">
          <div class="col-md-12 innerpage_slid">
            <img src="{{ asset('web/images/banner_larg.jpg') }}" alt="First slide">
            <div class="heading_titl"><a name="ab">About Us</a></div>
          </div>
        </div>
      </div>
    </section>
  <section id="bgwite">
    <div class="container articalbg">
      <div class="row ">
        <div class="col-md-12">
          <h1>About Us</h1>
        </div>
      </div>
      <div class="row">
        <div class="col-sm-8 col-md-8 about_detai wow fadeInRight">
          <h3>Welcome to Our Website</h3>
          <p> <img src="{{ asset('web/images/1.jpg') }}" /> <strong>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt Lorem ipsum dolor sit amet, consectetur</strong><br />
            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt. </p>
        </div>
        <div class="col-sm-4 col-md-4 boxgrid_3 wow fadeInLeft animated">
          <h2>Testimonials</h2>
          <blockquote class="quote">
            <div class="quote_inner">
              <p>Aenean nomy hendrerit mauris. Phasellus porta. Fusce suscipit varius. </p>
              <p class="quote-title">Paul Wendy, Sunday Ltd.</p>
            </div>
          </blockquote>
          <blockquote class="quote">
            <div class="quote_inner">
              <p>Aenean nomy hendrerit mauris. Phasellus porta. Fusce suscipit varius. </p>
              <p class="quote-title">Paul Wendy, Sunday Ltd.</p>
            </div>
          </blockquote>
          <div class="more_btn"> <a href="testimonials.php"><i class="fa fa-arrow-circle-o-left"></i> View More </a></div>
        </div>
      </div>
    </div>
  </section>
  <div class="cl"></div>
  
  <section id="fixbg">
    <div class="container ">
      <div class="row">
        <div class="col-md-12 wow fadeInLeft ">
          <h1>Direct Steel Sales. </h1>
          <h3>All Week! </h3>
          <br />
          <div class="requestbtn"><a href="#" class="btn btn-primary btn-lg">Request for Offer</a></div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12 wow fadeInRight "> </div>
      </div>
    </div>
    <div class="tranbgcolor">
      <div class="container ">
        <div class="row">
          <div class="col-md-12">
            <ul id="flexiselDemo3">
            <li><a href="#"><img src="{{ asset('web/images/clientlogo1.jpg') }}" alt="" title="" /></a></li>
              <li><a href="#"><img src="{{ asset('web/images/clientlogo2.jpg') }}" /></a></li>
              <li><a href="#"><img src="{{ asset('web/images/clientlogo3.jpg') }}" /></a></li>
              <li><a href="#"><img src="{{ asset('web/images/clientlogo4.jpg') }}" /></a></li>
              <li><a href="#"><img src="{{ asset('web/images/clientlogo5.jpg') }}" /></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>  
@endsection
